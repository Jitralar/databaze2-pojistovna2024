INSERT INTO BANKA (ID_banka, nazev, adresa_ID_adresa, kontakt_ID_kontakt) VALUES (1,'�esk�spo�itelna',40,20);
INSERT INTO BANKA (ID_banka, nazev, adresa_ID_adresa, kontakt_ID_kontakt) VALUES (2,'�eskoslovensk�obchodn�banka',41,21);
INSERT INTO BANKA (ID_banka, nazev, adresa_ID_adresa, kontakt_ID_kontakt) VALUES (3,'Komer�n�banka',42,22);
INSERT INTO BANKA (ID_banka, nazev, adresa_ID_adresa, kontakt_ID_kontakt) VALUES (4,'UniCreditBankCzechRepublicandSlovakia',43,23);
INSERT INTO BANKA (ID_banka, nazev, adresa_ID_adresa, kontakt_ID_kontakt) VALUES (5,'Raiffeisenbank',44,24);
INSERT INTO BANKA (ID_banka, nazev, adresa_ID_adresa, kontakt_ID_kontakt) VALUES (6,'Hypote�n�banka',45,25);
INSERT INTO BANKA (ID_banka, nazev,adresa_ID_adresa,kontakt_ID_kontakt)VALUES(7,'PPFBanka',46,26);
INSERT INTO BANKA (ID_banka, nazev,adresa_ID_adresa,kontakt_ID_kontakt)VALUES(8,'MonetaMoneyBank',47,27);
INSERT INTO BANKA (ID_banka, nazev,adresa_ID_adresa,kontakt_ID_kontakt)VALUES(9,'JaTBanka',48,28);
INSERT INTO BANKA (ID_banka, nazev,adresa_ID_adresa,kontakt_ID_kontakt)VALUES(10,'�SOBStavebn�spo�itelna',49,29);
INSERT INTO BANKA (ID_banka, nazev,adresa_ID_adresa,kontakt_ID_kontakt)VALUES(11,'Fiobanka',50,30);
INSERT INTO BANKA (ID_banka, nazev,adresa_ID_adresa,kontakt_ID_kontakt)VALUES(12,'AirBank',51,31);
INSERT INTO BANKA (ID_banka, nazev,adresa_ID_adresa,kontakt_ID_kontakt)VALUES(13,'Modr�pyramidastavebn�spo�itelna',52,32);
INSERT INTO BANKA (ID_banka, nazev,adresa_ID_adresa,kontakt_ID_kontakt)VALUES(14,'Stavebn� spo�itelna �esk� spo�itelny',53,33);
INSERT INTO BANKA (ID_banka, nazev,adresa_ID_adresa,kontakt_ID_kontakt)VALUES(15,'Raiffeisenstavebn�spo�itelna',54,34);
INSERT INTO BANKA (ID_banka, nazev,adresa_ID_adresa,kontakt_ID_kontakt)VALUES(16,'�esk�exportn�banka',55,35);
INSERT INTO BANKA (ID_banka, nazev,adresa_ID_adresa,kontakt_ID_kontakt)VALUES(17,'Equabank',56,36);
INSERT INTO BANKA (ID_banka, nazev,adresa_ID_adresa,kontakt_ID_kontakt)VALUES(18,'BankaCreditas',57,37);
INSERT INTO BANKA (ID_banka, nazev,adresa_ID_adresa,kontakt_ID_kontakt)VALUES(19,'MonetaStavebn�spo�itelna',58,38);
  
   

																																										
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(1,'Jeron�mova','1','943','Velk�Beranov','58821','',10);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(2,'Umedv�dk�','15','257','Pecice','26232','',2);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(3,'Jana��astn�ho','9','1000','SlapyNadVltavou','25232','',2);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(4,'H�bitovn�','','658','TrnavaUZl�na','25208','1',12);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(5,'Ml�nsk�','2','452','�sov','76318','5',14);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(6,'Nov�','','178','VojkoviceUKralupNadVltavou','78918','',1);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(7,'Ehrmannova','69','185','Debl�n','78973','',11);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(8,'Havl��kova','6','6987','Sedlcany','27744',6,2);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(9,'MarieKude��kov�','','658','Velk�Svatonovice','66475','',8);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(10,'Jeron�mova','33','633','Stonarov','26401','',10);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(11,'Tylova','35','358','OstrovNadOhr�','54235',5,5);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(12,'Nezvalova','74','74','Tuchomerice','58833','',2);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(13,'Partyz�nsk�','','81','Pustimer','36301','',11);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(14,'V�trn�k','','158','OtoviceUBroumova','25267',2,8);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(15,'Masarykova','1','9654','Humpolec','68341','',10);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(16,'Ji�n�','1','98','Vele��n','54972','',3);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(17,'Sokolsk�','33','56','DubNadMoravou','39601',3,13);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(18,'Al�ova','69','54','C�ov�','38232',4,3);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(19,'Tyr�ova','98','33','Hora�dovice','78375','',4);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(20,'Havl��kova','1','334','Dobr�','26301',1,2);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(21,'Masarykova','','1446','Humpolec','39601',1,10);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(22,'KLuk�rn�','23','294','Kom�rovUHorovic','26762',1,2);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(23,'Komensk�ho','','1254','Telc','58856',2,10);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(24,'Sokolsk�','','1667','Hrotovice','67555',-1,10);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(25,'Smetanova','11','914','Prelouc','53501',0,9);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(26,'Bart�kova','15','1567','Slezsk�Rudoltice','79397','',13);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(27,'Ml�de�nick�','','476','Habartov','35709','',5);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(28,'Opltova','','759','StankoviceU�atce','43949',5,6);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(29,'NaPr�honu','5','280','Druztov�','33007',6,4);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(30,'Jir�skova','','1740','MarkvarticeUSobotky','50742','',8);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(31,'Hradn�','','52','Nov�Bystrice','37833',1,3);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(32,'Opltova','','1233','Tuchorice','43969',2,6);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(33,'P���n�','9','999','Horn�Becva','75657',1,12);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(34,'Dru�stevn�','','1655','Zbiroh','33808',1,4);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(35,'Al�ova','','363','Pribyslav','58222',1,10);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(36,'St�edn�','1','1543','�tenovice','33209','',4);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(37,'UTrati','','1835','Kralovice','33141',3,4);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(38,'NaV�slun�','14','1327','BorUTachova','34802','',4);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(39,'ZaV�slun�','18','1677','BorUTachova','34802','',4);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(40,'Lidick�','27','669','Litomy�l','57001',1,9);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(41,'Jeron�mova','4','1531','Sobeslav','39201','',3);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(42,'P���n�','','135','Za�ov�','75651','',12);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(43,'H�bitovn�','45','1701','BiskupiceULuhacovic','76341','',12);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(44,'Al�ova','','550','Kestrany','39821',2,3);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(45,'H�bitovn�','','1781','Ka�ava','76319','',12);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(46,'Palack�ho','','1924','Hole�ov','76901','',12);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(47,'Matiegkova','','366','Pravon�n','25709','',2);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(48,'Jind�ichova','11','951','NovosedlyNadNe��rkou','37817','',3);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(49,'�zk�','','1645','Vlasatice','69130',1,11);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(50,'Ji�n�','36','7','Vetrn�','38211','',3);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(51,'VZahrad�ch','','292','Doma�eliceUPrerova','75115','',14);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(52,'NaLou�k�ch','','1128','Olomucany','67903',3,11);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(53,'Dru�stevn�','','1201','Velk�B�lovice','69102','',11);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(54,'Ma0sarykova','2','1136','Humpolec','39601','',10);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(55,'N�b�e�n�','','1667','Roupov','33453',6,4);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(56,'Matiegkova','','1801','Divi�ov','25726','',2);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(57,'Rva�ov','7','985','RoudniceNadLabem','41301','',6);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(58,'Jakutsk�','14','423','Praha','10000',2,1);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(59,'Tyr�ova','','1469','Slavonice','37881',1,3);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(56,'Jeron�mova','','943','Velk�Beranov','58821',-2,10);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(57,'Umedv�dk�','','257','Pecice','26232','',2);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(58,'Jana��astn�ho','','1000','SlapyNadVltavou','25208','',2);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(59,'H�bitovn�','','341','TrnavaUZl�na','76318',4,12);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(60,'Ml�nsk�','','1878','�sov','78973',2,14);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(61,'Nov�','','391','VojkoviceUKralupNadVltavou','27744','',1);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(62,'Ehrmannova','','1763','Debl�n','66475','',11);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(63,'Havl��kova','','1043','Sedlcany','26401','',2);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(64,'MarieKude��kov�','','174','Velk�Svatonovice','54235','',8);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(65,'Jeron�mova','','897','Stonarov','58833',2,10);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(66,'Tylova','','1735','OstrovNadOhr�','36301',1,5);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(67,'Nezvalova','','568','Tuchomerice','25267',1,2);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(68,'Partyz�nsk�','','81','Pustimer','68321',3,11);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(69,'V�trn�k','','1478','OtoviceUBroumova','54972','',8);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(70,'Masarykova','','1458','Humpolec','39601','',10);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(71,'Ji�n�','','378','Vele��n','38232',6,3);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(72,'Sokolsk�','','896','DubNadMoravou','78375','',13);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(73,'Al�ova','','479','C�ov�','39831','',3);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(74,'Tyr�ova','','366','Ostravice','34101',1,4);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(75,'UTrati','74','537','Nechanice','73914',1,13);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(76,'Bavorovsk�','1','716','Nov�Stra�ec�','50315',0,8);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(77,'�eskoslovensk�legi�','','769','Pl�nice','27101','',2);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(78,'�koln�','','1167','Kralovice','34034',0,4);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(79,'Nezvalova','','1528','Stachy','33141','',4);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(80,'NaPr�honu','','851','Horn�Mo�tenice','38473','',3);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(81,'Kov��sk�','4','1539','Bechyne','75117','',14);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(82,'KPazdern�','','1588','Kamenn�Pr�voz','39165','',3);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(83,'Prokopsk�','','965','MnichovoHradi�te','25282',1,2);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(84,'Masarykova','47','709','Telnice','29501','',2);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(85,'Nezvalova','','690','Vla�im','40338',2,6);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(86,'�echova','3','1987','Nov�Kn�n','25801','',2);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(87,'Budovatelsk�','3','1778','Breznice','26203',4,2);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(88,'Poln�','','615','J�lov�UPrahy','26272','',2);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(89,'Pivovarsk�','11','1818','Skutec','25401','',2);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(90,'Dru�stevn�','','1873','DoubraviceUStrakonic','53973',1,9);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(91,'Slune�n�','','306','Kozolupy','38735','',3);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(92,'K�hlerova','2','1196','Liten','33032','',4);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(93,'Slune�n�','','999','Hostim','26727','',2);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(94,'Lomen�','','1931','Budi�ovNadBudi�ovkou','25401','1',11);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(95,'Poln�','45','416','Hroznov�Lhota','53973',1,13);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(96,'B�rtova','11','1396','Melc','38735','',11);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(97,'Dru�stevn�','','329','Horn�Dunajovice','33032',3,13);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(98,'Pivovarsk�','4','798','N�rany','26727','',11);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(99,'�koln�','','927','�ebetov','67154','',4);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(100,'Jir�skova','','665','Hrabetice','74787',4,11);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(101,'K�hlerova','','91','C�kovice','69663','',11);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(102,'Matiegkova','','786','Mal�ice','74784','',6);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(103,'Ml�nsk�','12','1791','LomniceNadPopelkou','67134','',3);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(104,'Sokolovsk�','','332','Hroznov�Lhota','33023','',7);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(105,'Vostel�ick�','','1566','Pravon�n','67935','',11);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(106,'Tyr�ova','4','1452','Javorn�kUJesen�ku','67168',2,2);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(107,'Al�ova','','1670','Moravsk�Beroun','41112','',14);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(108,'Erbenova','','843','Vysok�M�to','39175','',13);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(109,'Velk�pr�hon','','861','Trebon','51251',1,9);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(110,'Ji��hozPod�brad','1','1313','�toky','69663','',3);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(111,'Sokolsk�','','1475','Dobr�','25709',1,10);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(112,'NaV�slun�','9','1935','Opocnice','79070','',8);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(113,'Lu�n�','15','1311','Praha','79305',4,1);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(114,'Lidick�','9','703','Dlouh�Loucka','56601',1,13);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(115,'Matiegkova','2','784','Velk�Pr�lepy','37901',1,2);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(116,'NaV�slun�','4','848','Nedvedice','58253',0,10);
INSERT INTO ADRESA(ID_adresa,ulice,cislo_orientacni,cislo_popisne,mesto,psc,patro,kraj_ID_kraj)VALUES(117,'Palack�ho','1','1291','Doksy','51793','1',7);			


    
    /
    

    
    
    
INSERT INTO POBOCKA(ID_pobocka, pocet_zamestnancu,nazev,adresa_ID_adresa)VALUES(1,1,'p1',1);
INSERT INTO POBOCKA(ID_pobocka, pocet_zamestnancu,nazev,adresa_ID_adresa)VALUES(2,0,'p2',2);
INSERT INTO POBOCKA(ID_pobocka, pocet_zamestnancu,nazev,adresa_ID_adresa)VALUES(3,1,'p3',3);
INSERT INTO POBOCKA(ID_pobocka, pocet_zamestnancu,nazev,adresa_ID_adresa)VALUES(4,1,'p4',4);
INSERT INTO POBOCKA(ID_pobocka, pocet_zamestnancu,nazev,adresa_ID_adresa)VALUES(5,1,'p5',5);
INSERT INTO POBOCKA(ID_pobocka, pocet_zamestnancu,nazev,adresa_ID_adresa)VALUES(6,1,'p6',6);
INSERT INTO POBOCKA(ID_pobocka, pocet_zamestnancu,nazev,adresa_ID_adresa)VALUES(7,1,'p7',7);
INSERT INTO POBOCKA(ID_pobocka, pocet_zamestnancu,nazev,adresa_ID_adresa)VALUES(8,0,'p8',8);
INSERT INTO POBOCKA(ID_pobocka, pocet_zamestnancu,nazev,adresa_ID_adresa)VALUES(9,1,'p9',9);
INSERT INTO POBOCKA(ID_pobocka, pocet_zamestnancu,nazev,adresa_ID_adresa)VALUES(10,1,'p10',10);
INSERT INTO POBOCKA(ID_pobocka, pocet_zamestnancu,nazev,adresa_ID_adresa)VALUES(11,1,'p11',11);
INSERT INTO POBOCKA(ID_pobocka, pocet_zamestnancu,nazev,adresa_ID_adresa)VALUES(12,1,'p12',12);
INSERT INTO POBOCKA(ID_pobocka, pocet_zamestnancu,nazev,adresa_ID_adresa)VALUES(13,1,'p13',13);
INSERT INTO POBOCKA(ID_pobocka, pocet_zamestnancu,nazev,adresa_ID_adresa)VALUES(14,1,'p14',14);
INSERT INTO POBOCKA(ID_pobocka, pocet_zamestnancu,nazev,adresa_ID_adresa)VALUES(15,1,'p15',15);
INSERT INTO POBOCKA(ID_pobocka, pocet_zamestnancu,nazev,adresa_ID_adresa)VALUES(16,1,'p16',16);
INSERT INTO POBOCKA(ID_pobocka, pocet_zamestnancu,nazev,adresa_ID_adresa)VALUES(17,1,'p17',17);
INSERT INTO POBOCKA(ID_pobocka, pocet_zamestnancu,nazev,adresa_ID_adresa)VALUES(18,1,'p18',18);
INSERT INTO POBOCKA(ID_pobocka, pocet_zamestnancu,nazev,adresa_ID_adresa)VALUES(19,1,'p19',19);
INSERT INTO POBOCKA(ID_pobocka, pocet_zamestnancu,nazev,adresa_ID_adresa)VALUES(20,3,'centrala',20);


    
    /
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(1,789562145,572455037,'clkao@icloud.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(2,null,532738094,'crowl@gmail.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(3,null,310593970,'nogin@mac.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(4,null,738743923,'scottlee@hotmail.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(5,null,722633271,'kayvonf@gmail.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(6,null,317091417,'nimaclea@yahoo.ca');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(7,null,322666114,'burniske@att.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(8,null,567264144,'mkearl@me.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(9,null,725028619,'campware@yahoo.ca');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(10,null,773661610,'qmacro@optonline.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(11,null,603493129,'bmidd@me.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(12,null,564576952,'drewf@att.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(13,null,569098090,'chaffar@yahoo.ca');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(14,null,605643300,'bryanw@comcast.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(15,785669324,776187912,'jbearp@icloud.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(16,null,490157290,'kosact@live.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(17,null,321355091,'errxn@hotmail.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(18,785999641,606888768,'kludge@hotmail.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(19,null,773025018,'staikos@live.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(20,652324120,549709830,'vlefevre@att.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(21,856123478,771589121,'scato@aol.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(22,null,462186041,'ismail@comcast.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(23,null,729896806,'paulv@hotmail.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(24,null,318109509,'yamla@sbcglobal.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(25,null,314688062,'dexter@verizon.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(26,null,324438008,'daveed@gmail.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(27,789663201,734088355,'preneel@yahoo.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(28,null,608432890,'zwood@mac.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(29,null,328560250,'nullchar@att.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(30,null,774017961,'smartfart@gmail.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(31,null,314584409,'jbailie@outlook.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(32,null,315267985,'joglo@yahoo.ca');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(33,null,595347243,'oevans@comcast.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(34,null,394229478,'martink@att.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(35,584896300,540749000,'crusader@live.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(36,123000785,775210110,'galbra@live.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(37,null,312428060,'flakeg@yahoo.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(38,null,545089262,'nasor@aol.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(39,894756332,778499797,'juerd@hotmail.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(40,785693214,583838966,'lamky@aol.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(41,785632001,777605326,'jmorris@icloud.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(42,null,729887119,'webdragon@me.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(43,null,314048950,'johnbob@hotmail.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(44,null,318276758,'boein@verizon.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(45,null,468136682,'hoangle@live.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(46,789663201,467383547,'evilopie@optonline.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(47,null,472181180,'bolow@aol.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(48,null,779037583,'psichel@icloud.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(49,null,498858273,'redingtn@icloud.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(50,null,726318183,'miltchev@outlook.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(51,785669147,770651626,'geekgrl@optonline.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(52,158974123,728972771,'tskirvin@me.com');
    
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(53,null,560306362,'moxfulder@verizon.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(54,584896301,564588591,'dvdotnet@hotmail.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(55,198000785,772010465,'brickbat@optonline.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(56,null,607390730,'mrsam@msn.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(57,null,726188976,'msloan@icloud.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(58,114852300,604032962,'panolex@live.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(59,null,568388070,'cliffski@comcast.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(60,null,485903782,'burns@comcast.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(61,785963324,733948737,'keiji@outlook.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(62,null,325548667,'gomor@comcast.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(63,null,608429840,'farber@me.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(64,null,481129515,'birddog@mac.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(65,null,601277323,'jshirley@mac.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(66,null,601949329,'rohitm@live.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(67,null,605015613,'neuffer@icloud.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(68,null,564716174,'speeves@att.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(69,null,604770990,'jelmer@optonline.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(70,null,778224928,'parkes@me.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(71,null,608805814,'bruck@me.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(72,null,564071608,'gomor@msn.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(73,null,474213821,'drhyde@comcast.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(74,785240469,770293927,'novanet1@hotmail.com');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(75,null,326434098,'alias@sbcglobal.net');
INSERT INTO KONTAKT(ID_kontakt,telefon,mobil,email)VALUES(76,null,739172469,'enintend@me.com');	
																	
																	
																	
																	

    
    /
INSERT INTO ZAMESTNANEC(ID_zam,jmeno,druhe_jmeno,prijmeni,adresa_ID_adresa,pozice_ID_pozice,kontakt_ID_kontakt)VALUES(1,'Jakub','null','Koz�r',21,4,1);
INSERT INTO ZAMESTNANEC(ID_zam,jmeno,druhe_jmeno,prijmeni,adresa_ID_adresa,pozice_ID_pozice,kontakt_ID_kontakt)VALUES(2,'Blahoslav','null','Janou�ek',22,5,2);
INSERT INTO ZAMESTNANEC(ID_zam,jmeno,druhe_jmeno,prijmeni,adresa_ID_adresa,pozice_ID_pozice,kontakt_ID_kontakt)VALUES(3,'Bartolom�j','Frank','Jaro�',23,9,3);
INSERT INTO ZAMESTNANEC(ID_zam,jmeno,druhe_jmeno,prijmeni,adresa_ID_adresa,pozice_ID_pozice,kontakt_ID_kontakt)VALUES(4,'Bartolom�j','null','Prokop',24,15,4);
INSERT INTO ZAMESTNANEC(ID_zam,jmeno,druhe_jmeno,prijmeni,adresa_ID_adresa,pozice_ID_pozice,kontakt_ID_kontakt)VALUES(5,'Bla�ej','null','��ek',25,7,5);
INSERT INTO ZAMESTNANEC(ID_zam,jmeno,druhe_jmeno,prijmeni,adresa_ID_adresa,pozice_ID_pozice,kontakt_ID_kontakt) VALUES(6,'Alexej','Ivan','Koz�k',26,3,6);
INSERT INTO ZAMESTNANEC(ID_zam,jmeno,druhe_jmeno,prijmeni,adresa_ID_adresa,pozice_ID_pozice,kontakt_ID_kontakt)VALUES(7,'Julius','Galius','�ech',27,6,7);
INSERT INTO ZAMESTNANEC(ID_zam,jmeno,druhe_jmeno,prijmeni,adresa_ID_adresa,pozice_ID_pozice,kontakt_ID_kontakt)VALUES(8,'Mat�j','null','Slez�k',28,7,8);
INSERT INTO ZAMESTNANEC(ID_zam,jmeno,druhe_jmeno,prijmeni,adresa_ID_adresa,pozice_ID_pozice,kontakt_ID_kontakt)VALUES(9,'Albert','null','Dosko�il',29,8,9);
INSERT INTO ZAMESTNANEC(ID_zam,jmeno,druhe_jmeno,prijmeni,adresa_ID_adresa,pozice_ID_pozice,kontakt_ID_kontakt)VALUES(10,'Ivan','null','Ho�ek',30,11,10);
INSERT INTO ZAMESTNANEC(ID_zam,jmeno,druhe_jmeno,prijmeni,adresa_ID_adresa,pozice_ID_pozice,kontakt_ID_kontakt)VALUES(11,'Klement','Jakub','Beran',31,23,11);
INSERT INTO ZAMESTNANEC(ID_zam,jmeno,druhe_jmeno,prijmeni,adresa_ID_adresa,pozice_ID_pozice,kontakt_ID_kontakt)VALUES(12,'�en�k','null','Va���ek',32,31,12);
INSERT INTO ZAMESTNANEC(ID_zam,jmeno,druhe_jmeno,prijmeni,adresa_ID_adresa,pozice_ID_pozice,kontakt_ID_kontakt)VALUES(13,'Josef','David','Krej��',33,1,13);
INSERT INTO ZAMESTNANEC(ID_zam,jmeno,druhe_jmeno,prijmeni,adresa_ID_adresa,pozice_ID_pozice,kontakt_ID_kontakt)VALUES(14,'Bed�ich','null','�apek',34,2,14);
INSERT INTO ZAMESTNANEC(ID_zam,jmeno,druhe_jmeno,prijmeni,adresa_ID_adresa,pozice_ID_pozice,kontakt_ID_kontakt)VALUES(15,'Sob�slav','null','Ku�aj',35,3,15);
INSERT INTO ZAMESTNANEC(ID_zam,jmeno,druhe_jmeno,prijmeni,adresa_ID_adresa,pozice_ID_pozice,kontakt_ID_kontakt)VALUES(16,'�en�k','Anton','Dvo���ek',36,4,16);
INSERT INTO ZAMESTNANEC(ID_zam,jmeno,druhe_jmeno,prijmeni,adresa_ID_adresa,pozice_ID_pozice,kontakt_ID_kontakt)VALUES(17,'Jakub','null','Mr�zek',37,8,17);
INSERT INTO ZAMESTNANEC(ID_zam,jmeno,druhe_jmeno,prijmeni,adresa_ID_adresa,pozice_ID_pozice,kontakt_ID_kontakt)VALUES(18,'Benedikt','null','Toman',38,6,18);
INSERT INTO ZAMESTNANEC(ID_zam,jmeno,druhe_jmeno,prijmeni,adresa_ID_adresa,pozice_ID_pozice,kontakt_ID_kontakt)VALUES(19,'�imon','Pavel','Bro�',39,7,19);


    
    /
    



    
    /
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (2,'Mojm�r','null','Nov��ek','26/08/1987','171572',60,40);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (3,'Kristi�n','null','Kraus','24/04/1989','445260',61,41);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (4,'Ladislav','Tom�','Ut�kal','14/08/1990','54145',62,42);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (5,'Ctibor','null','Kub�k','24/10/1990','299390',63,43);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (6,'Andrej','null','Kol��','19/04/1991','205158',64,44);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (7,'Oliver','null','Kr�l','23/08/1994','487246',65,45);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (8,'Mat�j','Pavel','Ture�ek','29/01/1997','211655',66,46);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (9,'�imon','null','N�me�ek','08/07/1997','348766',67,47);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (10,'Kamil','null','Dohnal','28/05/1998','66717',68,48);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (11,'Sebastian','null','Kol��','11/09/2000','278287',69,49);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (12,'Filip','null','Zapletal','24/10/2001','183403',70,50);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (13,'David','null','Stejskal','22/05/2003','326878',71,51);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (14,'Albert','null','Bro�','09/08/2004','56741',72,52);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (15,'V�nceslav','null','Stejskal','07/06/2005','246141',73,53);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (16,'Dalimil','null','Ka�par','26/09/2005','260259',74,54);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (17,'Daniel','null','�r�mek','01/11/2005','251492',75,55);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (18,'Kamil','Oto','Havl�k','31/08/2006','401263',76,56);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (19,'Radom�r','null','Zme�kal','14/05/2008','104882',77,57);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (20,'Drahoslav','null','Dohnal','15/12/1992','171572',78,39);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (21,'Andrej','Alois','Han�k','29/09/1993','445260',79,40);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (22,'Teodor','null','��k','05/09/1994','54145',80,41);

INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (23,'Emanuel','null','Han�k','13/03/1995','299390',81,42);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (24,'Radek','Petr','Linhart','15/08/1995','205158',82,43);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (25,'Oleg','null','�ev��k','16/08/1995','487246',83,44);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (26,'Jarom�r','null','Kub�k','21/11/1995','211655',84,45);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (27,'Drahoslav','null','Va���ek','20/04/1998','348766',85,46);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (28,'Otakar','null','Bla�ek','30/09/1998','66717',86,47);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (29,'Zikmund','null','Van�k','12/07/1999','278287',87,48);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (30,'Bla�ej','null','�eh�k','20/04/2000','183403',88,49);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (31,'Teodor','Alex','Va���ek','26/01/2001','326878',89,50);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (32,'Kv�toslava','null','N�mcov�','30/04/2001','56741',90,51);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (33,'Old�i�ka','null','Jel�nkov�','10/12/2002','246141',91,52);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (34,'Ljuba','null','Mare�kov�','19/12/2002','260259',92,53);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (35,'Tereza','null','Radov�','26/05/2004','251492',93,54);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (36,'Zde�ka','null','P�ikrylov�','24/02/2005','401263',94,55);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (37,'Simona','null','Pavelkov�','22/11/2005','104882',95,56);
INSERT INTO KLIENT (ID_klient, jmeno, druhe_jmeno, prijmeni, datum_narozeni, prijem, adresa_ID_adresa, kontakt_ID_kontakt) VALUES  (38,'Apolena','null','Jel�nkov�','11/06/2008','346824',96,57);
/
    
    
INSERT INTO kategorie_majetek (id_kat_majetku , nazev_kategorie) values (1,'auto');
INSERT INTO kategorie_majetek (id_kat_majetku , nazev_kategorie) values (2,'byt');
INSERT INTO kategorie_majetek (id_kat_majetku , nazev_kategorie) values (3,'kolo');
INSERT INTO kategorie_majetek (id_kat_majetku , nazev_kategorie) values (4,'dum');
INSERT INTO kategorie_majetek (id_kat_majetku , nazev_kategorie) values (5,'socha');
INSERT INTO kategorie_majetek (id_kat_majetku , nazev_kategorie) values (6,'po��ta�');
INSERT INTO kategorie_majetek (id_kat_majetku , nazev_kategorie) values (7,'laptop');
INSERT INTO kategorie_majetek (id_kat_majetku , nazev_kategorie) values (8,'mobil');
INSERT INTO kategorie_majetek (id_kat_majetku , nazev_kategorie) values (9,'nabytek');
INSERT INTO kategorie_majetek (id_kat_majetku , nazev_kategorie) values (10,'osobni_veci');
INSERT INTO kategorie_majetek (id_kat_majetku , nazev_kategorie) values (11,'elektrorozvody');
INSERT INTO kategorie_majetek (id_kat_majetku , nazev_kategorie) values (12,'obleceni');
INSERT INTO kategorie_majetek (id_kat_majetku , nazev_kategorie) values (13,'boty');
INSERT INTO kategorie_majetek (id_kat_majetku , nazev_kategorie) values (14,'sbirka');
INSERT INTO kategorie_majetek (id_kat_majetku , nazev_kategorie) values (15,'staro�itnosti');
INSERT INTO kategorie_majetek (id_kat_majetku , nazev_kategorie) values (16,'zbran�');
INSERT INTO kategorie_majetek (id_kat_majetku , nazev_kategorie) values (17,'cennosti');
INSERT INTO kategorie_majetek (id_kat_majetku , nazev_kategorie) values (18,'pozemek');
INSERT INTO kategorie_majetek (id_kat_majetku , nazev_kategorie) values (19,'jine');

INSERT INTO kategorie_majetek (id_kat_majetku , nazev_kategorie) values (20, 'test');

    
    /
    
    INSERT INTO POZICE VALUES (1,'Advok�t ','zastupujepoji��ovnu ',20000);
INSERT INTO POZICE VALUES (2,'Advok�tn�koncipient ','zastupujeadvokata ',45200);
INSERT INTO POZICE VALUES (3,'Analytik ','analyzujerizika ',32544);
INSERT INTO POZICE VALUES (4,'ITpodpora ','opravujetechniku ',63000);
INSERT INTO POZICE VALUES (5,'Pokladn� ','spravujepen�zenapobo�ce ',54100);
INSERT INTO POZICE VALUES (6,'Ekonom ','po��t�rentabilitu ',65200);
INSERT INTO POZICE VALUES (7,'Exekutor ','vym�h�dluh ',32000);
INSERT INTO POZICE VALUES (8,'Finan�n�analytik ','analyzujefinance ',14000);
INSERT INTO POZICE VALUES (9,'Finan�n�mana�er ','finance ',34000);
INSERT INTO POZICE VALUES (10,'Finan�n�poradce ','finance ',65000);
INSERT INTO POZICE VALUES (11,'Finan�n�specialista ','finance ',78200);
INSERT INTO POZICE VALUES (12,'Finan�n��editel ','zodpov�dn�zafinance ',100000);
INSERT INTO POZICE VALUES (13,'Fundraiser ','z�sk�v�finance ',32000);
INSERT INTO POZICE VALUES (14,'Hypote�n�specialista ','odborn�knamajetek ',23000);
INSERT INTO POZICE VALUES (15,'Investi�n�poradce ','odborniknainvestice ',10000);
INSERT INTO POZICE VALUES (16,'Likvid�tor ','likvid�tor ',78000);
INSERT INTO POZICE VALUES (17,'Makl�� ','nab�z�produkty ',32500);
INSERT INTO POZICE VALUES (18,'Not�� ','zapisujeaov��ujesmlouvy ',80240);
INSERT INTO POZICE VALUES (19,'Odhadce ','odhadujecenu ',40000);
INSERT INTO POZICE VALUES (20,'Poji��ovac�poradce ','rad�klientum ',98541);
INSERT INTO POZICE VALUES (21,'Poji��ovac�specialista ','specialistanapojisteni ',14500);
INSERT INTO POZICE VALUES (22,'Pr�vn�k ','hlidadodr�ov�n�pr�va ',100000);
INSERT INTO POZICE VALUES (23,'Rozpo�t�� ','navrhujerozpo�et ',86000);
INSERT INTO POZICE VALUES (24,'Ukl�ze� ','ukl�z� ',20000);
INSERT INTO POZICE VALUES (25,'Soudn�zapisovatel ','zapisuje ',15000);
INSERT INTO POZICE VALUES (26,'Specialistapohled�vek ','specialista ',4000);
INSERT INTO POZICE VALUES (27,'ITdevelopment ','vyv�j� ',150000);
INSERT INTO POZICE VALUES (28,'�v�rov�specialista ','specialistana�v�ry ',45132);
    
--p



INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (1,'14/06/2021','22/11/2023','z');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (2,'23/06/2021','15/12/2023','p');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (3,'24/09/2021','12/02/2024','z');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (4,'29/10/2021','04/06/2024','z');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (5,'30/11/2021','31/03/2025','z');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (6,'02/12/2021','03/04/2025','z');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (7,'15/12/2021','20/01/2026','z');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (8,'15/02/2022','07/07/2026','p');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (9,'16/02/2022','29/10/2026','p');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (10,'01/03/2022','23/11/2026','z');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (11,'02/03/2022','05/03/2027','p');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (12,'28/04/2022','29/02/2028','p');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (13,'16/05/2022','12/05/2028','p');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (14,'07/06/2022','18/08/2028','p');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (15,'26/07/2022','13/09/2028','z');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (16,'22/09/2022','01/11/2028','p');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (17,'20/10/2022','09/03/2029','p');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (18,'28/11/2022','04/04/2029','z');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (19,'07/12/2022','06/08/2029','p');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (20,'08/01/2021','29/09/2023','z');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (21,'15/06/2021','04/03/2024','p');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (22,'02/07/2021','25/04/2024','z');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (23,'09/08/2021','07/01/2025','z');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (24,'07/09/2021','12/06/2025','z');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (25,'19/10/2021','16/07/2025','p');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (26,'28/10/2021','15/08/2025','p');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (27,'10/11/2021','09/01/2026','z');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (28,'01/12/2021','16/03/2026','z');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (29,'29/12/2021','29/05/2026','p');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (30,'03/01/2022','16/06/2026','p');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (31,'06/01/2022','06/11/2026','z');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (32,'22/02/2022','16/02/2027','z');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (33,'23/02/2022','17/05/2027','p');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (34,'18/03/2022','31/08/2027','z');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (35,'24/03/2022','04/05/2028','p');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (36,'28/03/2022','28/08/2028','p');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (37,'11/05/2022','22/02/2029','p');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (38,'19/07/2022','27/08/2029','z');
INSERT INTO POVINOSTI (ID_POV_povinosti, POV_datum_vytvoreni, POV_datum_zplatnosti, POV_ID_arc) VALUES (39,'14/06/2021','05/06/2023','z');

--100 p
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(40,'18/12/2021','19/08/2023','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(41,'14/01/2022','06/04/2024','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(42,'27/01/2022','23/05/2024','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(43,'29/01/2022','25/11/2024','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(44,'10/02/2022','19/02/2025','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(45,'13/02/2022','22/10/2025','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(46,'15/02/2022','07/01/2026','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(47,'25/03/2022','10/09/2026','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(48,'29/03/2022','20/10/2026','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(49,'10/04/2022','28/03/2028','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(50,'22/04/2022','12/01/2029','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(51,'22/05/2022','26/03/2029','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(52,'31/05/2022','31/03/2029','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(53,'06/06/2022','03/08/2029','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(54,'23/06/2022','07/12/2029','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(55,'26/06/2022','22/01/2030','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(56,'05/07/2022','12/10/2030','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(57,'10/08/2022','21/03/2031','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(58,'25/08/2022','19/06/2031','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(59,'05/09/2022','19/12/2031','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(60,'25/09/2022','11/03/2033','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(61,'28/09/2022','09/05/2033','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(62,'12/10/2022','14/02/2034','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(63,'09/11/2022','16/05/2034','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(64,'24/11/2022','02/07/2025','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(65,'10/12/2021','14/07/2025','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(66,'15/12/2021','18/06/2026','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(67,'16/12/2021','19/06/2026','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(68,'17/12/2021','07/10/2026','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(69,'23/01/2022','06/04/2027','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(70,'01/02/2022','19/06/2027','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(71,'03/02/2022','05/09/2027','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(72,'06/02/2022','18/09/2027','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(73,'10/02/2022','14/05/2028','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(74,'08/03/2022','16/06/2028','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(75,'20/03/2022','06/07/2028','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(76,'28/03/2022','08/08/2028','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(77,'06/04/2022','02/08/2029','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(78,'10/04/2022','27/10/2029','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(79,'15/04/2022','14/12/2030','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(80,'28/04/2022','04/01/2031','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(81,'15/05/2022','29/03/2031','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(82,'23/06/2022','23/01/2032','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(83,'09/07/2022','12/05/2032','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(84,'12/07/2022','24/07/2032','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(85,'13/07/2022','29/10/2032','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(86,'01/09/2022','07/05/2033','p');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(87,'03/10/2022','14/01/2034','p');

--z
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(88,'06/11/2022','25/04/2034','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(89,'04/12/2022','22/02/2024','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(90,'20/12/2021','25/05/2024','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(91,'06/01/2022','14/02/2025','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(92,'08/01/2022','17/07/2025','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(93,'14/01/2022','26/11/2025','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(94,'20/01/2022','23/05/2026','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(95,'25/01/2022','07/10/2026','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(96,'31/01/2022','27/09/2027','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(97,'07/02/2022','29/01/2028','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(98,'24/02/2022','21/07/2028','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(99,'15/03/2022','07/08/2028','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(100,'22/03/2022','25/08/2029','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(101,'15/04/2022','17/11/2029','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(102,'18/04/2022','17/01/2030','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(103,'01/05/2022','06/06/2031','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(104,'15/05/2022','24/07/2031','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(105,'14/06/2022','24/10/2031','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(106,'24/06/2022','28/12/2031','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(107,'29/07/2022','20/03/2032','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(108,'22/08/2022','24/07/2032','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(109,'07/09/2022','20/01/2033','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(110,'08/09/2022','27/09/2033','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(111,'10/09/2022','27/12/2033','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(112,'14/09/2022','25/04/2034','z');
INSERT INTO POVINOSTI(ID_POV_povinosti,POV_datum_vytvoreni,POV_datum_zplatnosti,POV_ID_arc)VALUES(113,'17/10/2022','11/08/2034','z');
    
    /
    
    

INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(21,40,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(22,41,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(23,42,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(24,43,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(25,44,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(26,45,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(27,46,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(28,47,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(29,48,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(30,49,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(31,50,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(32,51,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(33,52,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(34,53,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(35,54,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(36,55,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(37,56,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(38,57,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(39,58,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(40,59,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(41,60,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(42,61,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(43,62,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(44,63,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(45,64,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(46,65,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(47,66,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(48,67,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(49,68,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(50,69,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(51,70,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(52,71,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(53,72,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(54,73,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(55,74,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(56,75,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(57,76,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(58,77,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(59,78,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(60,79,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(61,80,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(62,81,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(63,82,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(64,83,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(65,84,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(66,85,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(67,86,'standartn�pohled�vka');
INSERT INTO POHLEDAVKA (POH_ID_pohledavka, ID_POV_povinosti,POH_popis) VALUES(68,87,'standartn�pohled�vka');




INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(73,88,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(74,89,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(75,90,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(76,91,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(77,92,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(78,93,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(79,94,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(80,95,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(81,96,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(82,97,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(83,98,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(84,99,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(85,100,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(86,101,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(87,102,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(88,103,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(89,104,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(90,105,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(91,106,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(92,107,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(93,108,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(94,109,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(95,110,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(96,111,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(97,112,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(98,113,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(99,114,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(100,115,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(101,116,'odkaz na smlouvuv pdf');
INSERT INTO ZAVAZEK(ZAV_ID_zavazek,ID_POV_povinosti,ZAV_popis)VALUES(102,117,'odkaz na smlouvuv pdf');

    
    /
    
---chybi povinosti???    
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(1,'08/01/2021','','22198669','3949',1,'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(2,'08/01/2021','VIP klient','91972983','9091',2,'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(3,'08/01/2021','','58420381','8267',3,'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(4,'08/01/2021','','80582371','2600',4,'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(5,'08/01/2021','','17420212','5754',5,'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(6,'08/01/2021','klient si p�eje brzy nav��it m�s��n� spl�tku','27115151','564',6,'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(7,'08/01/2021','','97921859','9653',7,'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(8,'08/01/2021','','9501124','1483',8,'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(9,'08/01/2021','','51197414','7822',9,'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(10,'08/01/2021','','43280115','5159',10,'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(11,'08/01/2021','','42698921','919',11,'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(12,'08/01/2021','mo�nost odlo�en� 2 spl�tek','84831348','7158',12,'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(13,'08/01/2021','','24553233','6211',13,'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(14,'08/01/2021','','7333034','4927',14,'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(15,'08/01/2021','','66197694','3755',15,'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(16,'08/01/2021','','81667374','2168',16,'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(17,'08/01/2021','','13899276','6174',17,'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(18,'08/01/2021','','3902908','2471',18,'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(19,'08/01/2021','prov��itpojistku','23809713','7500',19,'P');

INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(20, '08/01/2021', 'null','4266500 ','6975 ',20, 'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(21, '08/01/2021', 'null','6967500 ','1517 ',21, 'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(22, '08/01/2021', 'null','4962500 ','1244 ',22, 'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(23, '08/01/2021', 'null','1862500 ','5156 ',23, 'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(24, '08/01/2021', 'null','8966500 ','9364 ',24, 'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(25, '08/01/2021', 'null','3409500 ','6705 ',25, 'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(26, '08/01/2021', 'null','9585500 ','1620 ',26, 'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(27, '08/01/2021', 'null','3900500 ','1307 ',27, 'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(28, '08/01/2021', 'null','8364500 ','7067 ',28, 'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(29, '08/01/2021', 'null','7460500 ','6219 ',29, 'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(30, '08/01/2021', 'null','5624500 ','8288 ',30, 'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(31, '08/01/2021', 'null','2970500 ','4776 ',31, 'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(32, '08/01/2021', 'null','2569500 ','7915 ',32, 'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(33, '08/01/2021', 'null','4981500 ','6577 ',33, 'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(34, '08/01/2021', 'null','2806500 ','8136 ',34, 'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(35, '08/01/2021', 'null','9399500 ','2740 ',35, 'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(36, '08/01/2021', 'null','5798500 ','3628 ',36, 'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(37, '08/01/2021', 'null','3304500 ','9202 ',37, 'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(38, '08/01/2021', 'null','3619500 ','6092 ',38, 'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(39, '08/01/2021', 'null','8149500 ','2521 ',39, 'U');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(40, '08/01/2021', 'null','2183500 ','8669 ',40, 'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(41, '08/01/2021', 'null','3022500 ','4336 ',41, 'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(42, '08/01/2021', 'null','9300500 ','6814 ',42, 'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(43, '08/01/2021', 'null','6679500 ','9609 ',43, 'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(44, '08/01/2021', 'null','5714500 ','5059 ',44, 'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(45, '08/01/2021', 'null','8165500 ','6256 ',45, 'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(46, '08/01/2021', 'null','5933500 ','8341 ',46, 'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(47, '08/01/2021', 'null','7417500 ','3825 ',47, 'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(48, '08/01/2021', 'null','2014500 ','7451 ',48, 'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(49, '08/01/2021', 'null','3886500 ','2719 ',49, 'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(50, '08/01/2021', 'null','1976500 ','6959 ',50, 'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(51, '08/01/2021', 'null','2301500 ','1193 ',51, 'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(52, '08/01/2021', 'null','7132500 ','7688 ',52, 'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(53, '08/01/2021', 'null','4801500 ','7167 ',53, 'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(54, '08/01/2021', 'null','5195500 ','9094 ',54, 'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(55, '08/01/2021', 'null','2236500 ','2264 ',55, 'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(56, '08/01/2021', 'null','7303500 ','5539 ',56, 'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(57, '08/01/2021', 'null','7638500 ','6930 ',57, 'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(58, '08/01/2021', 'null','9938500 ','1151 ',58, 'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(59, '08/01/2021', 'null','4380500 ','9519 ',59, 'P');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(60, '08/01/2021', 'null','7564500 ','7770 ',60, 'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(61, '08/01/2021', 'null','6824500 ','2691 ',61, 'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(62, '08/01/2021', 'null','8125500 ','2878 ',62, 'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(63, '08/01/2021', 'null','4537500 ','9316 ',63, 'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(64, '08/01/2021', 'null','9232500 ','9087 ',64, 'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(65, '08/01/2021', 'null','6236500 ','1329 ',65, 'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(66, '08/01/2021', 'null','2667500 ','5052 ',66, 'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(67, '08/01/2021', 'null','7342500 ','9256 ',67, 'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(68, '08/01/2021', 'null','2018500 ','5067 ',68, 'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(69, '08/01/2021', 'null','8930500 ','4155 ',69, 'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(70, '08/01/2021', 'null','4442500 ','1032 ',70, 'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(71, '08/01/2021', 'null','4016500 ','9204 ',71, 'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(72, '08/01/2021', 'null','9237500 ','5687 ',72, 'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(73, '08/01/2021', 'null','1808500 ','2128 ',73, 'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(74, '08/01/2021', 'null','4594500 ','2140 ',74, 'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(75, '08/01/2021', 'null','9646500 ','6623 ',75, 'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(76, '08/01/2021', 'null','1635500 ','5640 ',76, 'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(77, '08/01/2021', 'null','4011500 ','9413 ',77, 'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(78, '08/01/2021', 'null','4029500 ','1358 ',78, 'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(79, '08/01/2021', 'null','5268500 ','7457 ',79, 'M');
INSERT INTO POJISTKA(ID_POJ_pojisteni,POJ_datum_sjednani,POJ_poznamka,POJ_pojisteno_do,POJ_cena_mesicne,POV_ID_povinosti,POJ_ID_arc)VALUES(80, '08/01/2021', 'null','7611500 ','200 ',80, 'M');
    
    /

INSERT INTO PRIPOJISTENI (ID_PRI_pripojisteni, ID_POJ_pojisteni, PRI_druh, PRI_pouze_zem, PRI_cena_nad) VALUES (20,40,'spravne selecty','ne','1500');    
INSERT INTO PRIPOJISTENI (ID_PRI_pripojisteni, ID_POJ_pojisteni, PRI_druh, PRI_pouze_zem, PRI_cena_nad) VALUES (1,41,'extremnilyzovani','eu','1500');
INSERT INTO PRIPOJISTENI (ID_PRI_pripojisteni, ID_POJ_pojisteni, PRI_druh, PRI_pouze_zem, PRI_cena_nad) VALUES (2,42,'vodaWW2','eu,ua,bu,ma','800');
INSERT INTO PRIPOJISTENI (ID_PRI_pripojisteni, ID_POJ_pojisteni, PRI_druh, PRI_pouze_zem, PRI_cena_nad) VALUES (3,43,'vodaWW3','eu,usa','1000');
INSERT INTO PRIPOJISTENI (ID_PRI_pripojisteni, ID_POJ_pojisteni, PRI_druh, PRI_pouze_zem, PRI_cena_nad) VALUES (4,44,'horolezectvi','eu','650');
INSERT INTO PRIPOJISTENI (ID_PRI_pripojisteni, ID_POJ_pojisteni, PRI_druh, PRI_pouze_zem, PRI_cena_nad) VALUES (5,45,'skokyzletadla','eu','100');
INSERT INTO PRIPOJISTENI (ID_PRI_pripojisteni, ID_POJ_pojisteni, PRI_druh, PRI_pouze_zem, PRI_cena_nad) VALUE(6,46,'skokyzletadlabezpadaku','eu,ru,ua,usa','10000');

INSERT INTO PRIPOJISTENI (ID_PRI_pripojisteni, ID_POJ_pojisteni, PRI_druh, PRI_pouze_zem, PRI_cena_nad) VALUES (7,47,'bunjeejumping','eu','150');
INSERT INTO PRIPOJISTENI (ID_PRI_pripojisteni, ID_POJ_pojisteni, PRI_druh, PRI_pouze_zem, PRI_cena_nad) VALUES (8,48,'paraglayding','eu','8000');
INSERT INTO PRIPOJISTENI (ID_PRI_pripojisteni, ID_POJ_pojisteni, PRI_druh, PRI_pouze_zem, PRI_cena_nad) VALUES (9,49,'lepsiluzko','eu','500');
INSERT INTO PRIPOJISTENI (ID_PRI_pripojisteni, ID_POJ_pojisteni, PRI_druh, PRI_pouze_zem, PRI_cena_nad) VALUES (10,50,'jidlocosedajist','it','32000');
INSERT INTO PRIPOJISTENI (ID_PRI_pripojisteni, ID_POJ_pojisteni, PRI_druh, PRI_pouze_zem, PRI_cena_nad) VALUES (11,51,'pivodokapa�ky','usa,cz,au,d','25');
INSERT INTO PRIPOJISTENI (ID_PRI_pripojisteni, ID_POJ_pojisteni, PRI_druh, PRI_pouze_zem, PRI_cena_nad) VALUES (12,52,'fotkyzoperace','eu','700');
INSERT INTO PRIPOJISTENI (ID_PRI_pripojisteni, ID_POJ_pojisteni, PRI_druh, PRI_pouze_zem, PRI_cena_nad) VALUES (13,53,'cyklocross','eu','650');
INSERT INTO PRIPOJISTENI (ID_PRI_pripojisteni, ID_POJ_pojisteni, PRI_druh, PRI_pouze_zem, PRI_cena_nad) VALUES (14,54,'extremnisporty','eu','470');
INSERT INTO PRIPOJISTENI (ID_PRI_pripojisteni, ID_POJ_pojisteni, PRI_druh, PRI_pouze_zem, PRI_cena_nad) VALUES (15,55,'naodpov�dnost','eu','200');
INSERT INTO PRIPOJISTENI (ID_PRI_pripojisteni, ID_POJ_pojisteni, PRI_druh, PRI_pouze_zem, PRI_cena_nad) VALUES (16,56,'vrcholovyspotovec','eu','750');
INSERT INTO PRIPOJISTENI (ID_PRI_pripojisteni, ID_POJ_pojisteni, PRI_druh, PRI_pouze_zem, PRI_cena_nad) VALUES (17,57,'maraton','usa','1000');
INSERT INTO PRIPOJISTENI (ID_PRI_pripojisteni, ID_POJ_pojisteni, PRI_druh, PRI_pouze_zem, PRI_cena_nad) VALUES (18,58,'olympiada','jp','12666');
INSERT INTO PRIPOJISTENI (ID_PRI_pripojisteni, ID_POJ_pojisteni, PRI_druh, PRI_pouze_zem, PRI_cena_nad) VALUES (19,59,'d�l�n�n�semin�reknaposledn�chv�ly','eu','8000');


    
    /
           


INSERT INTO MAJETEK_POJISTENI(MAJ_ID_majetek, ID_POJ_pojisteni,MAJ_popis,MAJ_vyrobeno,ID_kat_majetku)VALUES(1,61,'audi a8','01/01/2020',1); 
INSERT INTO MAJETEK_POJISTENI(MAJ_ID_majetek, ID_POJ_pojisteni,MAJ_popis,MAJ_vyrobeno,ID_kat_majetku)VALUES(2,62,'skoda fabia','01/01/1999',1); 
INSERT INTO MAJETEK_POJISTENI(MAJ_ID_majetek, ID_POJ_pojisteni,MAJ_popis,MAJ_vyrobeno,ID_kat_majetku)VALUES(3,63,'byt stodulky','01/01/1978',2); 
INSERT INTO MAJETEK_POJISTENI(MAJ_ID_majetek, ID_POJ_pojisteni,MAJ_popis,MAJ_vyrobeno,ID_kat_majetku)VALUES(4,64,'schnile jabko','01/01/2022',8); 
INSERT INTO MAJETEK_POJISTENI(MAJ_ID_majetek, ID_POJ_pojisteni,MAJ_popis,MAJ_vyrobeno,ID_kat_majetku)VALUES(5,65,'dum se zahradou','01/01/1985',4);
INSERT INTO MAJETEK_POJISTENI(MAJ_ID_majetek, ID_POJ_pojisteni,MAJ_popis,MAJ_vyrobeno,ID_kat_majetku)VALUES(6,66,'i7 s rtx 3900','01/01/2022',6);
INSERT INTO MAJETEK_POJISTENI(MAJ_ID_majetek, ID_POJ_pojisteni,MAJ_popis,MAJ_vyrobeno,ID_kat_majetku)VALUES(7,67,'�erven� kolo','01/01/2018',3); 
INSERT INTO MAJETEK_POJISTENI(MAJ_ID_majetek, ID_POJ_pojisteni,MAJ_popis,MAJ_vyrobeno,ID_kat_majetku)VALUES(8,68,'byt uhrineves','01/01/1954',2); 
INSERT INTO MAJETEK_POJISTENI(MAJ_ID_majetek, ID_POJ_pojisteni,MAJ_popis,MAJ_vyrobeno,ID_kat_majetku)VALUES(9,69,'volvo','01/01/2000',1);  
INSERT INTO MAJETEK_POJISTENI(MAJ_ID_majetek, ID_POJ_pojisteni,MAJ_popis,MAJ_vyrobeno,ID_kat_majetku)VALUES(10,70,'Tank T72','01/01/1975',1); 
INSERT INTO MAJETEK_POJISTENI(MAJ_ID_majetek, ID_POJ_pojisteni,MAJ_popis,MAJ_vyrobeno,ID_kat_majetku)VALUES(11,71,'skrin z 1674','01/01/1674',9);
INSERT INTO MAJETEK_POJISTENI(MAJ_ID_majetek, ID_POJ_pojisteni,MAJ_popis,MAJ_vyrobeno,ID_kat_majetku)VALUES(12,72,'kartacek z diamantu','01/01/1752',10);
INSERT INTO MAJETEK_POJISTENI(MAJ_ID_majetek, ID_POJ_pojisteni,MAJ_popis,MAJ_vyrobeno,ID_kat_majetku)VALUES(13,73,'medeny kabel','01/01/2022',11); 
INSERT INTO MAJETEK_POJISTENI(MAJ_ID_majetek, ID_POJ_pojisteni,MAJ_popis,MAJ_vyrobeno,ID_kat_majetku)VALUES(14,74,'socha Davida','01/01/1471',5); 
INSERT INTO MAJETEK_POJISTENI(MAJ_ID_majetek, ID_POJ_pojisteni,MAJ_popis,MAJ_vyrobeno,ID_kat_majetku)VALUES(15,75,'strom pred domem','01/01/1919',19);
INSERT INTO MAJETEK_POJISTENI(MAJ_ID_majetek, ID_POJ_pojisteni,MAJ_popis,MAJ_vyrobeno,ID_kat_majetku)VALUES(16,76,'Gigachad android','01/01/2022',8); 
INSERT INTO MAJETEK_POJISTENI(MAJ_ID_majetek, ID_POJ_pojisteni,MAJ_popis,MAJ_vyrobeno,ID_kat_majetku)VALUES(17,77,'byt Brno','01/01/1968',2); 
INSERT INTO MAJETEK_POJISTENI(MAJ_ID_majetek, ID_POJ_pojisteni,MAJ_popis,MAJ_vyrobeno,ID_kat_majetku)VALUES(18,78,'byt Pardubice','01/01/1974',2); 
INSERT INTO MAJETEK_POJISTENI(MAJ_ID_majetek, ID_POJ_pojisteni,MAJ_popis,MAJ_vyrobeno,ID_kat_majetku)VALUES(19,79,'byt Praha','01/01/2008',2);
INSERT INTO MAJETEK_POJISTENI(MAJ_ID_majetek, ID_POJ_pojisteni,MAJ_popis,MAJ_vyrobeno,ID_kat_majetku)VALUES(20,80,'byt Praha','01/01/2018',2); 
 


--snadtonespadne

  
    --snad to nespadne
    