CREATE OR REPLACE VIEW A1 AS
select p.ID_pobocka,k.nazev_kraje, p.nazev
from pobocka p
JOIN adresa a
ON p.ADRESA_ID_ADRESA = a.id_adresa
JOIN kraj k
ON a.kraj_ID_kraj = k.ID_kraj
where kraj_id_kraj = 2;

select * from A1;

CREATE OR REPLACE VIEW A2 AS
select p.ID_pobocka,k.nazev_kraje, p.nazev
from pobocka p
JOIN adresa a
ON p.ADRESA_ID_ADRESA = a.id_adresa
JOIN kraj k
ON a.kraj_ID_kraj = k.ID_kraj
where kraj_id_kraj != 2;

select * from A2;

CREATE OR REPLACE VIEW D3 AS
select a.mesto , k.nazev_kraje
from adresa a
JOIN kraj k
ON a.kraj_ID_kraj = k.ID_kraj
where k.ID_kraj > 2 and (k.nazev_kraje != 'Jihomoravsky kraj');

select * from D3;


--d3
CREATE OR REPLACE VIEW D3 AS


select * from D3;

/*
CREATE OR REPLACE VIEW porovnavacKraju AS
select p1.kraj_ID_kraj , p2.kraj_ID_kraj
from porovnavacKraju1 p1
left join porovnavacKraju2 p2
where p1.kraj_ID_kraj != p2.kraj_ID_kraj;


CREATE OR REPLACE VIEW porovnavacKraju1 AS
select a.kraj_ID_kraj banka_kraj
 from adresa a 
 join banka b 
 on b.ADRESA_ID_ADRESA = a.id_adresa 
 where a.ID_adresa = b.ADRESA_ID_ADRESA;
 
CREATE OR REPLACE VIEW porovnavacKraju2 AS
select a.KRAJ_ID_kraj klient_kraj
from adresa a 
join klient kli 
on kli.ADRESA_ID_ADRESA = a.id_adresa 
where a.ID_adresa = kli.ADRESA_ID_ADRESA;

SELECT kli.jmeno, krj.mesto, ban.jmeno
from klient kli
join adresa a
on kli.ADRESA_ID_ADRESA = a.id_adresa
join banka ban
on a.banka_id_banka = ban.ID_banka
join kraj krj
on a.kraj_ID_kraj = krj.ID_kraj
where krj.ID_kraj = (select * from (select a.kraj_ID_kraj from adresa a join banka b on b.ADRESA_ID_ADRESA = a.id_adresa where a.ID_adresa = b.ADRESA_ID_ADRESA) = (select a.KRAJ_ID_kraj from adresa a join klient kli on kli.ADRESA_ID_ADRESA = a.id_adresa where a.ID_adresa = kli.ADRESA_ID_ADRESA););

*/

CREATE OR REPLACE VIEW D4 AS
select a.mesto nazev_mesta, k.nazev_kraje "Pod kter� kraj toto m�sto pat�� pat��:"
from adresa a
join kraj k
on a.kraj_ID_kraj = k.ID_kraj
where k.nazev_kraje = 'Jihomoravsky kraj' OR k.nazev_kraje = 'Moravskoslezsky kraj' 
order by k.nazev_kraje DESC;

select * from D4;

--D5

CREATE OR REPLACE VIEW D6 AS
select z.jmeno, z.prijmeni, p.nazev "N�zev vykon�van� pozice",p.plat "Plat m�s��n�", 12 * p.plat "O�ek�van� plat za rok"
from zamestnanec z
join pozice p
on z.POZICE_ID_pozice = p.ID_pozice
where p.plat > 50000
order by z.jmeno;

select * from D6;
/*
select pov.datum_vytvoreni "Den vzniku", poh.poh_popis "popis"
from povinosti pov
join pohledavka poh
using (pov.ID_POV_POVINOSTI IS poh.id_pov_povinosti);
*/

--d7
CREATE OR REPLACE VIEW D7 AS
SELECT *
FROM zamestnanec
NATURAL JOIN pozice
where ID_pozice = POZICE_ID_pozice
order by prijmeni;

select * from d7;


--d8
CREATE OR REPLACE VIEW D8 AS
SELECT zam.POZICE_ID_pozice, zam.jmeno, poz.nazev "N�zev postu"
FROM zamestnanec zam
CROSS JOIN pozice poz
where ID_pozice = POZICE_ID_pozice
order by zam.jmeno;

select * from d8 ;

CREATE OR REPLACE VIEW D9 AS
SELECT z.prijmeni "P�ijmen� zam�stnance",z.ID_zam "id Zam�stnance", p.nazev "N�zev postu"
FROM zamestnanec z
LEFT JOIN pozice p ON z.POZICE_ID_pozice = p.ID_pozice
ORDER BY z.prijmeni;

select * from d9;


CREATE OR REPLACE VIEW D10 AS
SELECT z.prijmeni "P�ijmen� zam�stnance",z.ID_zam "id Zam�stnance", p.nazev "N�zev postu"
FROM zamestnanec z
RIGHT JOIN pozice p ON z.POZICE_ID_pozice = p.ID_pozice
ORDER BY z.prijmeni;

select * from d10;

CREATE OR REPLACE VIEW D11 AS
SELECT z.prijmeni "P�ijmen� zam�stnance",z.ID_zam "id Zam�stnance", p.nazev "N�zev postu", p.plat "v�plata"
FROM zamestnanec z
FULL OUTER JOIN pozice p
ON z.POZICE_ID_pozice = p.ID_pozice
WHERE ID_pozice = POZICE_ID_pozice
ORDER BY p.plat DESC;

select * from d11;

/*
select * 
from klient kli
join kontakt kon
on kli.KONTAKT_ID_kontakt =  kon.ID_kontakt
where kli.druhe_jmeno != 'null' AND (select * from kontakt kon where kon.telefon != 'null')
order by kli.jmeno;
*/
CREATE OR REPLACE VIEW D12 AS
SELECT klient.ID_klient, klient.jmeno, klient.druhe_jmeno, klient.prijmeni, SUB1.telefon, SUB1.mobil, SUB1.email
FROM klient,
 (SELECT kontakt.ID_kontakt, kontakt.telefon, kontakt.mobil, kontakt.email
  FROM kontakt 
  WHERE kontakt.telefon != 'null') SUB1
WHERE SUB1.ID_kontakt = klient.KONTAKT_ID_kontakt AND
klient.druhe_jmeno != 'null';

select * from D12;


CREATE OR REPLACE VIEW D13 AS
select * 
from (select * from klient);

select * from D13;



/*
SELECT  z.prijmeni "P�ijmen� zam�stnance",z.ID_zam "id Zam�stnance", p.nazev "N�zev pracovi�t�"
FROM zamestnanec z
INNER JOIN pozice p ON z.POZICE_ID_pozice = p.ID_pozice
ORDER BY z.prijmeni;*/
